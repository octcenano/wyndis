#Requires -Version 5.1
<#
.SYNOPSIS
    Wyndis - Auditor de seguridad para Windows (estilo Lynis)
.DESCRIPTION
    Herramienta gratuita de auditoría para pequeñas empresas y usuarios domésticos.
    Ejecutar como Administrador para resultados completos.
    Contacto: wyndis.help@gmail.com
.EXAMPLE
    .\wyndis.ps1
.EXAMPLE
    .\wyndis.ps1 -Quick
#>

[CmdletBinding()]
param(
    [switch]$Quick,
    [switch]$NoColor,
    [string]$ReportPath
)

$ErrorActionPreference = 'SilentlyContinue'
$Script:WyndisVersion = '1.0.0'
$Script:WyndisStartTime = Get-Date
$Script:Findings = [System.Collections.Generic.List[object]]::new()
$Script:ReportLines = [System.Collections.Generic.List[string]]::new()

$LibPath = Join-Path $PSScriptRoot 'lib'
Get-ChildItem -Path $LibPath -Filter '*.ps1' | Sort-Object Name | ForEach-Object {
    . $_.FullName
}

function Start-Wyndis {
    Clear-Host
    Show-WyndisBanner

    $isAdmin = Test-WyndisAdmin
    if (-not $isAdmin) {
        Write-WyndisWarning 'No se ejecuta como Administrador. Algunas comprobaciones serán limitadas.'
        Write-WyndisSuggest 'Ejecuta: clic derecho en PowerShell -> "Ejecutar como administrador"'
    }

    Write-WyndisSection 'Información del sistema'
    Invoke-WyndisSystemInfo

    Write-WyndisSection 'Firewall de Windows'
    Invoke-WyndisFirewallAudit

    Write-WyndisSection 'Permisos y cuentas de usuario'
    Invoke-WyndisPermissionsAudit

    Write-WyndisSection 'Windows Update'
    Invoke-WyndisUpdateAudit

    Write-WyndisSection 'Antivirus (Windows Defender)'
    Invoke-WyndisDefenderAudit

    Write-WyndisSection 'Escritorio remoto (RDP)'
    Invoke-WyndisRdpAudit

    Write-WyndisSection 'Servicios peligrosos'
    Invoke-WyndisServicesAudit

    Write-WyndisSection 'Programas de inicio automático'
    Invoke-WyndisStartupAudit

    if (-not $Quick) {
        Write-WyndisSection 'Aplicaciones instaladas'
        Invoke-WyndisApplicationsAudit

        Write-WyndisSection 'Vida útil del sistema'
        Invoke-WyndisSystemLifeAudit

        Write-WyndisSection 'Recomendaciones de herramientas'
        Invoke-WyndisToolRecommendations
    }

    Write-WyndisSection 'Resumen y puntuación'
    $score = Get-WyndisScore
    Show-WyndisScore $score

    if ($ReportPath) {
        Export-WyndisReport -Path $ReportPath -Score $score
    }

    $elapsed = (Get-Date) - $Script:WyndisStartTime
    Write-Host ''
    Write-WyndisInfo "Auditoría completada en $($elapsed.TotalSeconds.ToString('F1')) segundos."
    Write-WyndisInfo 'Wyndis es 100% gratuito. Comparte con quien quieras.'
    Write-WyndisInfo 'Contacto: wyndis.help@gmail.com'
}

Start-Wyndis
